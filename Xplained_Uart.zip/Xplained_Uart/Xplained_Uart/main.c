#define F_CPU 16000000UL  // 16 MHz Clock
#include <avr/io.h>
#include <util/delay.h>

void uartInit(void) {
	UCSR0A |= (1 << U2X0);  // Enable double speed mode
	uint16_t ubrr_value = (F_CPU / (8UL * 115200)) - 1;
	UBRR0H = (ubrr_value >> 8);
	UBRR0L = ubrr_value;

	UCSR0B = (1 << TXEN0) | (1 << RXEN0);  // Enable TX and RX
	UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);  // 8-bit data, 1 stop bit, no parity
}
void uartSendByte(char byte) {
	while (!(UCSR0A & (1 << UDRE0)));  // Wait until the buffer is empty
	UDR0 = byte;
}

void uartSendStr(const char *str) {
	while (*str) {
		uartSendByte(*str++);
	}
}

char datatosend[] = "Ceyhun Pempeci!!!\r\n";

int main(void) {
	uartInit();
	while (1) {
		uartSendStr(datatosend);
		_delay_ms(1000);
	}
}